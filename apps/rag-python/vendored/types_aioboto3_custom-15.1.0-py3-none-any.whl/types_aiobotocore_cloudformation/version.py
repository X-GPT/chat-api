"""
Source of truth for version.

Copyright 2025 Vlad Emelianov
"""

__version__ = "15.1.0"
